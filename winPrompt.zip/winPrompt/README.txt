
Hi!  Go into winprompt, prompt, data, cmd helper, ambassador.txt. this is a file. Running it will
destroy ur cpu. It starts a bunch of notepads and nothing else. Run at ur own risk.
i am not responsible for any of the damage. This is a fun prank to play on a friend, But
if they have a bad pc, DO NOT RUN.

Made by Mlomax.